package com.gdm.srmwebapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SrmwebappApplication {

    public static void main(String[] args) {
        SpringApplication.run(SrmwebappApplication.class, args);
    }

}

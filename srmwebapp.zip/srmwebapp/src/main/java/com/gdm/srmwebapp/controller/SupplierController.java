package com.gdm.srmwebapp.controller;

import com.gdm.srmwebapp.service.SupplierService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value = {"/supplier"})
public class SupplierController {
    @Autowired
    private SupplierService supplierService;

    @GetMapping(value = {"/list"})
    public ModelAndView displaySuppliersList() {
        var modelAndView = new ModelAndView();
        modelAndView.addObject("suppliers", supplierService.getSuppliers());
        modelAndView.setViewName("supplier/suppliersList");
        return modelAndView;
    }

}
